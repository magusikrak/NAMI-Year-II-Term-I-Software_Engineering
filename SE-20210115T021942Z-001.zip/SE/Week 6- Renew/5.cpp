#include <iostream>
using namespace std;
int reverse(int arr[], int size){
    int rev[size];
    for (int i = 0, j = size - 1; i < size, j >=size; i++, j++) {
        
    }
}
int main(){
    int size;
    cout << "Enter array size:";
    cin >> size;

    int arr[size];
    for (int i = 0; i < size; ++i) {
        cout << "Enter index"<< i+1 << " value:";
        cin >> arr[i];
    }

}