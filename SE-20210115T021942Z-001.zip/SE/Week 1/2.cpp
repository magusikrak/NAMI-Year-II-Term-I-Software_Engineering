#include<iostream>
using namespace std;
int main(){
cout <<"A “quoted” String is much better if you learn the rules of escape sequences.” \n Also, “” represents an empty string";
}
