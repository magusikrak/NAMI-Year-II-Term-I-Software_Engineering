#include<iostream>
using namespace std;
int main(){
  cout << "Hello World"; // << == Stream insertion operator (Output)
                          // >> == Stream extraction operato r(Input)
  return(0);
}
