#include<iostream>
using namespace std;
int main(){
  int cookie, calorie = 30;
  cout << "How cookies did you eat: ";
  cin >> cookie;
  cout << "You consumed " << cookie * calorie << " calories";
}
