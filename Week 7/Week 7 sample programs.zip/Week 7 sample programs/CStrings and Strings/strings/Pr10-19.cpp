// This program initializes a string object.
#include <iostream>
#include <string>
using namespace std;

int main()
{
   string greeting;
   string name("William Smith");

   greeting = "Hello ";
   cout << greeting << name << endl;
   return 0;
}